package com.example.ds4mepper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot
import kotlin.math.min

class PadState {
    var lx = 0f; var ly = 0f
    var rx = 0f; var ry = 0f
    var lt = 0f; var rt = 0f
    var hatX = 0f; var hatY = 0f
    val pressed = mutableSetOf<Int>()
}

/**
 * Desenha o controle no estilo neon. Cinza = valor bruto, colorido = depois do perfil.
 * Tocar em um elemento chama onTap com o nome dele (LS, RS, L2, R2, L1, R1, UP, DOWN, LEFT,
 * RIGHT, Y, A, X, B, SELECT, START, MODE).
 */
class GamepadView(ctx: Context) : View(ctx) {
    val state = PadState()
    var profile = Profile()
    /** true = o valor já veio processado pelo motor; não aplicar o perfil de novo. */
    var passthrough = false
    var onTap: ((String) -> Unit)? = null
    /** Gesto rápido de subir e descer (ou descer e subir) com o dedo sobre um analógico desenhado. */
    var onStickGesture: ((String) -> Unit)? = null
    /** Analógico destacado enquanto o painel dele está aberto ("LS" ou "RS"). */
    var selected: String? = null
    /** Ponto (no espaço desta view) onde termina a linha que liga o analógico ao painel. */
    var link: PointF? = null

    private val stickRects = HashMap<String, RectF>()
    private val touchSlop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()

    /** Posição do analógico desenhado ("LS" ou "RS"), no espaço desta view. */
    fun stickRect(tag: String): RectF? = stickRects[tag]

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val hits = ArrayList<Pair<RectF, String>>()

    // Arte do controle (recorte da imagem de referência). Medidas do recorte: 720 x 518.
    private val photo: Bitmap? by lazy {
        try {
            val o = BitmapFactory.Options().apply { inScaled = false }
            BitmapFactory.decodeResource(resources, R.drawable.ds4_photo, o)
        } catch (t: Throwable) {
            null
        }
    }
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dzPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(200, 150, 84, 255)
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
    }

    private val cBlue = Color.rgb(46, 160, 255)
    private val cCyan = Color.rgb(0, 224, 212)
    private val cPink = Color.rgb(255, 72, 200)
    private val cRed = Color.rgb(255, 70, 92)
    private val cPurple = Color.rgb(150, 84, 255)
    private val cPanel = Color.rgb(20, 22, 52)
    private val cLabel = Color.rgb(206, 196, 255)
    private val cRing = Color.rgb(112, 108, 235)

    // Mostra o botão de SAÍDA: se Cross foi remapeado para Circle, apertar Cross acende Circle.
    private fun down(vararg codes: Int) = codes.any { out ->
        state.pressed.any { p -> (if (passthrough) p else profile.map(p)) == out }
    }

    private fun tv(v: Float, cfg: TriggerCfg) = if (passthrough) v else cfg.process(v)

    private fun withAlpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    private fun glowCircle(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, w: Float) {
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(color, 26 * (4 - i))
            stroke.strokeWidth = w + i * 5f
            c.drawCircle(cx, cy, r, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = w
        c.drawCircle(cx, cy, r, stroke)
    }

    private fun glowRect(c: Canvas, r: RectF, rad: Float, color: Int, w: Float) {
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(color, 26 * (4 - i))
            stroke.strokeWidth = w + i * 5f
            c.drawRoundRect(r, rad, rad, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = w
        c.drawRoundRect(r, rad, rad, stroke)
    }

    private fun tap(r: RectF, tag: String) {
        hits.add(RectF(r) to tag)
    }

    private var gTag: String? = null
    private var gDownX = 0f
    private var gDownY = 0f
    private var gDownT = 0L
    private var gMinY = 0f
    private var gMaxY = 0f
    private var gDone = false
    private var gMoved = false

    /** Qual analógico está sob o dedo (a área é um pouco maior que o desenho). */
    private fun stickAt(x: Float, y: Float): String? {
        for ((tag, r) in stickRects) {
            val m = r.width() * 0.12f
            if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) return tag
        }
        return null
    }

    /**
     * Tudo aqui acontece só na tela do app: nada disso é enviado ao jogo nem ao controle.
     * Toque no analógico = abre o painel. Subir e descer (ou descer e subir) rápido sobre ele,
     * em até 0,9 s, também abre.
     */
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gTag = stickAt(e.x, e.y)
                gDownX = e.x
                gDownY = e.y
                gDownT = e.eventTime
                gMinY = e.y
                gMaxY = e.y
                gDone = false
                gMoved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.x - gDownX, e.y - gDownY) > touchSlop) gMoved = true
                val tag = gTag
                if (tag != null && !gDone) {
                    if (e.y < gMinY) gMinY = e.y
                    if (e.y > gMaxY) gMaxY = e.y
                    val size = stickRects[tag]?.width() ?: 120f
                    val thr = size * 0.22f
                    val upThenDown = (gDownY - gMinY) >= thr && (e.y - gMinY) >= thr
                    val downThenUp = (gMaxY - gDownY) >= thr && (gMaxY - e.y) >= thr
                    if ((upThenDown || downThenUp) && e.eventTime - gDownT <= 900L) {
                        gDone = true
                        onStickGesture?.invoke(tag)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!gDone && !gMoved) {
                    for ((r, tag) in hits) {
                        if (r.contains(e.x, e.y)) {
                            onTap?.invoke(tag)
                            break
                        }
                    }
                }
                gTag = null
            }
            MotionEvent.ACTION_CANCEL -> {
                gTag = null
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        hits.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        text.textSize = h * 0.038f
        val u = h

        // ---------- corpo do controle: a arte da imagem de referência (ao fundo) ----------
        val pw0 = 720f
        val ph0 = 518f
        val dw = min(w * 0.58f, h * 0.78f * pw0 / ph0)
        val k = dw / pw0
        val dh = ph0 * k
        val left = cx - dw / 2f
        val topY = h * 0.58f - dh / 2f
        val art = photo
        if (art != null) {
            c.drawBitmap(art, null, RectF(left, topY, left + dw, topY + dh), photoPaint)
        }

        // ---------- gatilhos e ombros ----------
        trigger(c, w * 0.03f, h * 0.02f, w * 0.29f, h * 0.085f, tv(state.lt, profile.lt), "L2", "L2")
        trigger(c, w * 0.68f, h * 0.02f, w * 0.29f, h * 0.085f, tv(state.rt, profile.rt), "R2", "R2")
        shoulder(c, w * 0.03f, h * 0.125f, w * 0.29f, h * 0.075f, down(KeyEvent.KEYCODE_BUTTON_L1), "L1", "L1")
        shoulder(c, w * 0.68f, h * 0.125f, w * 0.29f, h * 0.075f, down(KeyEvent.KEYCODE_BUTTON_R1), "R1", "R1")

        // ---------- D-pad ----------
        val d = u * 0.115f
        val br = u * 0.05f
        val dx = w * 0.13f
        val dy = h * 0.47f
        round(c, dx, dy - d, br, down(KeyEvent.KEYCODE_DPAD_UP), "↑", Color.WHITE, "UP", cRing)
        round(c, dx, dy + d, br, down(KeyEvent.KEYCODE_DPAD_DOWN), "↓", Color.WHITE, "DOWN", cRing)
        round(c, dx - d, dy, br, down(KeyEvent.KEYCODE_DPAD_LEFT), "←", Color.WHITE, "LEFT", cRing)
        round(c, dx + d, dy, br, down(KeyEvent.KEYCODE_DPAD_RIGHT), "→", Color.WHITE, "RIGHT", cRing)

        // ---------- botões de ação (Android A/B/X/Y = ✕/○/□/△ do DS4) ----------
        val fx = w * 0.87f
        round(c, fx, dy - d, br, down(KeyEvent.KEYCODE_BUTTON_Y), "△", cCyan, "Y", cRing)
        round(c, fx, dy + d, br, down(KeyEvent.KEYCODE_BUTTON_A), "✕", cBlue, "A", cRing)
        round(c, fx - d, dy, br, down(KeyEvent.KEYCODE_BUTTON_X), "□", cPink, "X", cRing)
        round(c, fx + d, dy, br, down(KeyEvent.KEYCODE_BUTTON_B), "○", cRed, "B", cRing)

        // ---------- por cima da arte: barra de luz, Share, Options, PS e analógicos ----------
        // As medidas abaixo são posições dentro do recorte de 720 x 518.
        if (profile.led) {
            val led = Color.rgb(profile.ledR, profile.ledG, profile.ledB)
            stroke.color = withAlpha(led, 80)
            stroke.strokeWidth = 14f * k
            c.drawLine(left + 276f * k, topY + 41f * k, left + 450f * k, topY + 41f * k, stroke)
            stroke.color = led
            stroke.strokeWidth = 5f * k
            c.drawLine(left + 276f * k, topY + 41f * k, left + 450f * k, topY + 41f * k, stroke)
        }

        zone(c, RectF(left + 203f * k, topY + 41f * k, left + 243f * k, topY + 101f * k),
            down(KeyEvent.KEYCODE_BUTTON_SELECT), "SELECT", false)
        zone(c, RectF(left + 479f * k, topY + 41f * k, left + 519f * k, topY + 101f * k),
            down(KeyEvent.KEYCODE_BUTTON_START), "START", false)
        zone(c, RectF(left + 337f * k, topY + 211f * k, left + 385f * k, topY + 259f * k),
            down(KeyEvent.KEYCODE_BUTTON_MODE), "MODE", true)

        val sr = 62f * k
        stick(c, left + 251f * k, topY + 228f * k, sr, state.lx, state.ly, profile.left,
            down(KeyEvent.KEYCODE_BUTTON_THUMBL), "LS")
        stick(c, left + 469f * k, topY + 226f * k, sr, state.rx, state.ry, profile.right,
            down(KeyEvent.KEYCODE_BUTTON_THUMBR), "RS")

        // linha ciano do analógico selecionado até o painel dele
        val sel = selected
        val lk = link
        if (sel != null && lk != null) {
            val sr0 = stickRects[sel]
            if (sr0 != null) {
                val sx = sr0.centerX()
                val sy = sr0.centerY()
                val ang = Math.atan2((lk.y - sy).toDouble(), (lk.x - sx).toDouble())
                val rr = sr0.width() / 2f * 1.06f
                val ex = sx + rr * Math.cos(ang).toFloat()
                val ey = sy + rr * Math.sin(ang).toFloat()
                for (i in 3 downTo 1) {
                    stroke.color = withAlpha(cCyan, 30 * (4 - i))
                    stroke.strokeWidth = 2.5f + i * 4f
                    c.drawLine(ex, ey, lk.x, lk.y, stroke)
                }
                stroke.color = cCyan
                stroke.strokeWidth = 2.5f
                c.drawLine(ex, ey, lk.x, lk.y, stroke)
            }
        }
    }

    /** Área tocável sobre a arte; acende quando o botão está apertado. */
    private fun zone(c: Canvas, r: RectF, pressed: Boolean, tag: String, circle: Boolean) {
        if (pressed) {
            fill.color = withAlpha(cBlue, 130)
            if (circle) c.drawOval(r, fill) else c.drawRoundRect(r, r.width() / 2f, r.width() / 2f, fill)
        }
        tap(r, tag)
    }

    private fun round(c: Canvas, x: Float, y: Float, r: Float, pressed: Boolean, label: String, color: Int, tag: String, ring: Int = color) {
        fill.color = if (pressed) withAlpha(color, 170) else cPanel
        c.drawCircle(x, y, r, fill)
        glowCircle(c, x, y, r, ring, 2.5f)
        val old = text.color
        text.color = if (pressed) Color.WHITE else color
        text.textSize = r * 1.0f
        c.drawText(label, x, y + text.textSize * 0.35f, text)
        text.color = old
        text.textSize = height * 0.038f
        tap(RectF(x - r * 1.2f, y - r * 1.2f, x + r * 1.2f, y + r * 1.2f), tag)
    }

    private fun pill(c: Canvas, l: Float, t: Float, w: Float, h: Float, pressed: Boolean, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = if (pressed) withAlpha(cBlue, 170) else cPanel
        c.drawRoundRect(rect, h / 2, h / 2, fill)
        glowRect(c, rect, h / 2, withAlpha(cBlue, 210), 2f)
        text.textSize = h * 0.55f
        c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        text.textSize = height * 0.038f
        tap(rect, tag)
    }

    private fun shoulder(c: Canvas, l: Float, t: Float, w: Float, h: Float, pressed: Boolean, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = if (pressed) withAlpha(cCyan, 150) else cPanel
        c.drawRoundRect(rect, 14f, 14f, fill)
        glowRect(c, rect, 14f, cCyan, 2.5f)
        badge(c, rect, label)
        c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        tap(rect, tag)
    }

    private fun trigger(c: Canvas, l: Float, t: Float, w: Float, h: Float, v: Float, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = cPanel
        c.drawRoundRect(rect, 14f, 14f, fill)
        if (v > 0.001f) {
            fill.color = withAlpha(cCyan, 120)
            c.drawRoundRect(RectF(l, t, l + w * v.coerceIn(0f, 1f), t + h), 14f, 14f, fill)
        }
        glowRect(c, rect, 14f, cCyan, 2.5f)
        badge(c, rect, label)
        c.drawText("$label  ${"%.2f".format(v)}", rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        tap(rect, tag)
    }

    /** Quadradinho com o nome do botão, no canto esquerdo da barra. */
    private fun badge(c: Canvas, bar: RectF, label: String) {
        val s = bar.height() * 0.62f
        val b = RectF(bar.left + bar.height() * 0.18f, bar.centerY() - s / 2f, bar.left + bar.height() * 0.18f + s, bar.centerY() + s / 2f)
        stroke.color = cCyan; stroke.strokeWidth = 2f
        c.drawRoundRect(b, 6f, 6f, stroke)
        val old = text.textSize
        text.textSize = s * 0.50f
        text.color = cCyan
        c.drawText(label, b.centerX(), b.centerY() + text.textSize * 0.35f, text)
        text.color = Color.WHITE
        text.textSize = old
    }

    /** Analógico sobre a arte: cinza = valor bruto, ciano = depois do perfil. */
    private fun stick(c: Canvas, cx: Float, cy: Float, r: Float, rawX: Float, rawY: Float, cfg: StickCfg, pressed: Boolean, tag: String) {
        stickRects[tag] = RectF(cx - r, cy - r, cx + r, cy + r)
        if (photo == null) glowCircle(c, cx, cy, r, cBlue, 4f)
        if (selected == tag) glowCircle(c, cx, cy, r * 1.06f, cCyan, 3f)
        if (pressed) {
            fill.color = withAlpha(cPurple, 130)
            c.drawCircle(cx, cy, r, fill)
        }
        val travel = r * 0.62f
        // zona morta configurada
        c.drawCircle(cx, cy, travel * cfg.deadzone, dzPaint)
        // zona máxima configurada (só aparece quando é menor que 100%)
        if (cfg.maxZone < 0.99f) c.drawCircle(cx, cy, travel * cfg.maxZone, dzPaint)
        // valor bruto (cinza)
        fill.color = Color.argb(200, 150, 150, 150)
        c.drawCircle(cx + rawX * travel, cy + rawY * travel, r * 0.11f, fill)
        // valor processado
        val (vx, vy) = if (passthrough) (rawX to rawY) else cfg.process(rawX, rawY, profile.invertY)
        fill.color = cCyan
        c.drawCircle(cx + vx * travel, cy + vy * travel, r * 0.15f, fill)
        val old = text.textSize
        text.textSize = old * 0.80f
        text.color = cLabel
        c.drawText("%.2f  %.2f".format(vx, vy), cx, cy + r + old * 1.05f, text)
        text.color = Color.WHITE
        text.textSize = old
        tap(RectF(cx - r, cy - r, cx + r, cy + r), tag)
    }
}
