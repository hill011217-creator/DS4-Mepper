# DS4 Mepper: configure seu controle do jeito que quiser

App nativo em Kotlin. Este projeto compila sozinho na nuvem (GitHub Actions),
sem computador e sem Android Studio.

## O que o app faz
- **Interface neon em paisagem**: o controle aparece desenhado. Toque em um analógico para ajustar zona morta, curva e sensibilidade; em L2/R2 para o curso do gatilho; em qualquer botão para remapear ou ligar o turbo
- Painel com abas **Perfis**, **LED** e **Avançado**, barra de conexão (USB ou Bluetooth) e atalhos de cor do LED na parte de baixo
- Tela de teste: botões, D-pad, analógicos (cinza = bruto, azul = após o perfil) e gatilhos
- **Perfis**: crie vários (ex.: um por jogo) e troque pelo seletor; cada um guarda todos os ajustes abaixo
- **Analógicos**: zona morta e curva separadas para o esquerdo e o direito, e inverter Y
- **Gatilhos L2/R2**: zona morta inicial, ponto em que chegam ao máximo (curso curto) e curva
- **Turbo (segurar = repetir)**: toque rápido dá 1 clique; segurando, repete sozinho. Duração do clique e intervalo de 1 a 50 ms e atraso para começar (0 a 600 ms). O motor mede e mostra o ritmo real dos cliques
- Remapeamento de botões (botão a trocar -> botão destino)
- **LED do controle (experimental)**: cor RGB por perfil, pela API de luzes do Android 12+ (não precisa de Shizuku). O botão "Testar LED do controle" no Diagnóstico mostra se o seu aparelho aceita. Com a cor ligada, uma notificação fixa mantém o app vivo para o LED não apagar
- Intensidade da vibração, nome do controle, bateria (Android 12+) e teste de vibração
- **Motor (Shizuku)**: faz os ajustes valerem dentro de qualquer jogo
- **Diagnóstico**: testes do motor, do LED e uma "sondagem só de leitura" que mostra o que o aparelho permite (tela de toque, taxa de atualização, Game Mode, CPU/GPU)

> Para criar remapeamentos e escolher os botões do turbo, desative o motor.
> Depois de configurar, ative o motor e abra o jogo.

> O DS4 Mepper usa um identificador próprio (`com.example.ds4mepper`) e instala ao lado do PadStudio, do ForgePad,
> do StickLab e do PadTool, sem substituir. Pare o motor dos apps antigos (ou desinstale-os) antes de usar este e
> libere o DS4 Mepper no app Shizuku na primeira vez.

---

## COMO COMPILAR PELO CELULAR (passo a passo)

Você precisa de 2 arquivos: **DS4Mepper.zip** e **build.yml** (os dois vieram juntos
com este projeto). Deixe-os salvos no celular (pasta Downloads).

### 1. Criar conta no GitHub
Abra o Chrome e entre em **github.com** -> **Sign up**. Crie a conta e confirme o e-mail.

### 2. Criar o repositório (a "pasta" na nuvem)
1. Em github.com, toque no **+** (canto superior) -> **New repository**.
2. Em **Repository name** escreva: `ds4mepper`
3. Marque **Public** (assim a compilação é grátis e sem limite).
4. Marque **Add a README file**.
5. Toque em **Create repository**.

### 3. Enviar os 2 arquivos
1. Na página do repositório, toque em **Add file** -> **Upload files**.
2. Toque em **choose your files** e selecione **DS4Mepper.zip** e **build.yml** (os dois).
3. Espere carregar e toque em **Commit changes** (botão verde).

> Não achou o botão "Add file"? No Chrome, toque nos 3 pontinhos (⋮) e ative
> **Site para computador**. A tela fica pequena, mas aparece tudo.

### 4. Colocar o build.yml no lugar certo
O GitHub só reconhece o "robô de compilação" dentro da pasta `.github/workflows`.
Vamos mover o arquivo:
1. Na lista de arquivos do repositório, toque em **build.yml**.
2. Toque no ícone de **lápis** (Edit).
3. No campo do nome do arquivo (no topo), toque no início do texto `build.yml`
   e digite antes dele: `.github/workflows/`
   O campo deve ficar assim: `.github/workflows/build.yml`
4. Toque em **Commit changes...** -> **Commit changes**.

Se não conseguir editar o nome: toque em **Add file** -> **Create new file**, no nome
escreva `.github/workflows/build.yml`, cole o conteúdo do arquivo build.yml
(abra-o no celular e copie tudo) e dê **Commit changes**.

### 5. Iniciar a compilação
Ao fazer o passo 4, a compilação **começa sozinha**. Para acompanhar ou iniciar de novo:
1. Toque na aba **Actions** (se não aparecer, toque em **...** / **More** ou use "Site para computador").
2. Toque em **Build APK** (lista à esquerda; no celular, aparece a execução na lista).
3. Para iniciar manualmente: toque em **Run workflow** -> **Run workflow** (botão verde).
4. Espere de 4 a 10 minutos. Quando aparecer um **✔ verde**, terminou.
   Se aparecer um **✖ vermelho**, toque nele, abra o passo que falhou e me mande o texto do erro.

### 6. Baixar o APK
1. Volte à página principal do repositório (toque em **Code**).
2. Role para baixo até **Releases** e toque em **DS4Mepper - APK mais recente**.
3. Em **Assets**, toque em **DS4Mepper.apk**. O download começa.

(Backup: na página da execução, em **Artifacts**, existe também o **DS4Mepper-APK**, que vem dentro de um ZIP.)

### 7. Instalar no Samsung Galaxy A34
1. Abra o arquivo **DS4Mepper.apk** (toque na notificação de download ou abra em **Meus Arquivos -> Downloads**).
2. Se o Android avisar "por segurança, o telefone não permite instalar apps desta fonte",
   toque em **Configurações** e ative **Permitir desta fonte** para o Chrome (ou o navegador que usou).
3. Volte e toque em **Instalar**.
4. Se aparecer o aviso do **Play Protect** ("app não verificado"), toque em **Instalar mesmo assim**.
5. Se a instalação for bloqueada, desative o **Bloqueio automático (Auto Blocker)** em
   **Configurações -> Segurança e privacidade -> Bloqueio automático**.
   Depois da instalação você pode ligar de novo.

### Atualizar o app depois
Para trocar a versão: no repositório toque em **Add file -> Upload files**, envie o novo **DS4Mepper.zip**
(com o mesmo nome, ele substitui o antigo) e toque em **Commit changes**. A compilação começa sozinha.

Mudou algum arquivo no repositório? A compilação roda sozinha e o APK novo substitui o
anterior na aba Releases. O APK novo instala por cima do antigo, sem perder as configurações
(todas as compilações usam a mesma chave de assinatura).

---

## Para quem usa computador
Pode subir a pasta inteira do projeto para o repositório (já inclui `.github/workflows/build.yml`).
Para abrir no Android Studio: File -> Open -> pasta do projeto.

## Detalhes técnicos
- Kotlin, Android Gradle Plugin 8.5.2, Gradle 8.7, Java 17, compileSdk/targetSdk 34, minSdk 26
- Sem bibliotecas externas (só o SDK do Android)
- APK debug assinado com `app/debug.keystore` (chave pública de teste, normal para uso pessoal)

## Motores de outros apps

Ao tocar em **Ativar**, o DS4 Mepper agora encerra sozinho motores de outros apps (PadPulse, StickLab, PadTool etc.)
que estejam rodando, porque um deles com o DS4 bloqueado impede este de pegar o controle. Se o motor parar,
o motivo aparece na linha de status ("Motor: parado." seguido do erro).
