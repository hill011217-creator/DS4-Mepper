package com.example.ds4mepper

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.pow

/** Ajustes de um analógico: zona morta radial + curva. */
data class StickCfg(
    var deadzone: Float = 0.10f,   // 0..0.5
    var curve: Float = 1.0f,       // 0.5..3 (1 = linear)
    var sens: Float = 1.0f         // 0.5..1.5 (1 = 100%): ganho da saída
) {
    /** Entrada e saída em -1..1. */
    fun process(x: Float, y: Float, invertY: Boolean): Pair<Float, Float> {
        val mag = hypot(x, y)
        if (mag <= deadzone || mag == 0f) return 0f to 0f
        val scaled = ((mag - deadzone) / (1f - deadzone)).coerceIn(0f, 1f)
        val out = (scaled.pow(curve) * sens).coerceAtMost(1f)
        val ox = x / mag * out
        var oy = y / mag * out
        if (invertY) oy = -oy
        return ox to oy
    }
}

/** Ajustes de um gatilho: onde começa a responder, onde chega ao máximo e a curva. */
data class TriggerCfg(
    var start: Float = 0.0f,   // 0..0.4  (zona morta inicial)
    var max: Float = 1.0f,     // 0.5..1  (curso curto: chega ao máximo antes)
    var curve: Float = 1.0f    // 0.5..3
) {
    fun process(v: Float): Float {
        val span = (max - start).coerceAtLeast(0.05f)
        val s = ((v.coerceIn(0f, 1f) - start) / span).coerceIn(0f, 1f)
        return s.pow(curve)
    }
}

/** Um perfil completo de configuração. */
data class Profile(
    var name: String = "Padrão",
    val left: StickCfg = StickCfg(),
    val right: StickCfg = StickCfg(),
    val lt: TriggerCfg = TriggerCfg(),
    val rt: TriggerCfg = TriggerCfg(),
    var invertY: Boolean = false,
    var vibration: Float = 0.6f,                         // 0..1
    var turboOn: Int = 5,                                // ms com o botão apertado em cada clique (1..50)
    var turboOff: Int = 5,                               // ms solto entre um clique e o próximo (1..50)
    var turboDelay: Int = 200,                           // ms segurando antes de começar a repetir (0..600)
    val turbo: MutableSet<Int> = mutableSetOf(),         // keyCodes dos botões físicos com turbo
    val remap: MutableMap<Int, Int> = mutableMapOf(),    // keyCode físico -> keyCode destino
    var led: Boolean = false,                            // usar cor personalizada no LED
    var ledR: Int = 0,                                   // 0..255
    var ledG: Int = 120,
    var ledB: Int = 255
) {
    fun stickL(x: Float, y: Float) = left.process(x, y, invertY)
    fun stickR(x: Float, y: Float) = right.process(x, y, invertY)

    /** Botão físico -> botão depois do remapeamento. */
    fun map(code: Int): Int = remap[code] ?: code

    /** Cópia profunda (os objetos de dentro também são copiados). */
    fun snapshot() = Profile(
        name, left.copy(), right.copy(), lt.copy(), rt.copy(),
        invertY, vibration, turboOn, turboOff, turboDelay, turbo.toMutableSet(), remap.toMutableMap(),
        led, ledR, ledG, ledB
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("lz", left.deadzone.toDouble()); put("lc", left.curve.toDouble()); put("ls", left.sens.toDouble())
        put("rz", right.deadzone.toDouble()); put("rc", right.curve.toDouble()); put("rs", right.sens.toDouble())
        put("lts", lt.start.toDouble()); put("ltm", lt.max.toDouble()); put("ltc", lt.curve.toDouble())
        put("rts", rt.start.toDouble()); put("rtm", rt.max.toDouble()); put("rtc", rt.curve.toDouble())
        put("invertY", invertY)
        put("vib", vibration.toDouble())
        put("ton", turboOn); put("toff", turboOff); put("tdelay", turboDelay)
        put("led", led); put("lr", ledR); put("lg", ledG); put("lb", ledB)
        put("turbo", JSONArray(turbo.toList()))
        put("remap", JSONArray(remap.entries.map { "${it.key}:${it.value}" }))
    }

    companion object {
        fun fromJson(j: JSONObject): Profile {
            val p = Profile(name = j.optString("name", "Padrão"))
            p.left.deadzone = j.optDouble("lz", 0.10).toFloat()
            p.left.curve = j.optDouble("lc", 1.0).toFloat()
            p.left.sens = j.optDouble("ls", 1.0).toFloat().coerceIn(0.3f, 3f)
            p.right.deadzone = j.optDouble("rz", 0.10).toFloat()
            p.right.curve = j.optDouble("rc", 1.0).toFloat()
            p.right.sens = j.optDouble("rs", 1.0).toFloat().coerceIn(0.3f, 3f)
            p.lt.start = j.optDouble("lts", 0.0).toFloat()
            p.lt.max = j.optDouble("ltm", 1.0).toFloat()
            p.lt.curve = j.optDouble("ltc", 1.0).toFloat()
            p.rt.start = j.optDouble("rts", 0.0).toFloat()
            p.rt.max = j.optDouble("rtm", 1.0).toFloat()
            p.rt.curve = j.optDouble("rtc", 1.0).toFloat()
            p.invertY = j.optBoolean("invertY", false)
            p.vibration = j.optDouble("vib", 0.6).toFloat()
            p.turboOn = j.optInt("ton", 5).coerceIn(1, 50)
            p.turboOff = j.optInt("toff", 5).coerceIn(1, 50)
            p.turboDelay = j.optInt("tdelay", 200).coerceIn(0, 600)
            p.led = j.optBoolean("led", false)
            p.ledR = j.optInt("lr", 0).coerceIn(0, 255)
            p.ledG = j.optInt("lg", 120).coerceIn(0, 255)
            p.ledB = j.optInt("lb", 255).coerceIn(0, 255)
            j.optJSONArray("turbo")?.let { a -> for (i in 0 until a.length()) p.turbo.add(a.getInt(i)) }
            j.optJSONArray("remap")?.let { a ->
                for (i in 0 until a.length()) {
                    val parts = a.getString(i).split(":")
                    val from = parts.getOrNull(0)?.toIntOrNull()
                    val to = parts.getOrNull(1)?.toIntOrNull()
                    if (from != null && to != null) p.remap[from] = to
                }
            }
            return p
        }
    }
}

/** Botões físicos do DS4 que aceitam turbo (o D-pad fica de fora). */
val TURBO_KEYS = setOf(
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
    KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_BUTTON_THUMBL,
    KeyEvent.KEYCODE_BUTTON_THUMBR, KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_START
)

/** Nome do botão no padrão PlayStation. */
fun buttonName(code: Int): String = when (code) {
    KeyEvent.KEYCODE_BUTTON_A -> "✕"
    KeyEvent.KEYCODE_BUTTON_B -> "○"
    KeyEvent.KEYCODE_BUTTON_X -> "□"
    KeyEvent.KEYCODE_BUTTON_Y -> "△"
    KeyEvent.KEYCODE_BUTTON_L1 -> "L1"
    KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
    KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
    KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
    KeyEvent.KEYCODE_BUTTON_THUMBL -> "L3"
    KeyEvent.KEYCODE_BUTTON_THUMBR -> "R3"
    KeyEvent.KEYCODE_BUTTON_SELECT -> "Share"
    KeyEvent.KEYCODE_BUTTON_START -> "Options"
    KeyEvent.KEYCODE_BUTTON_MODE -> "PS"
    KeyEvent.KEYCODE_DPAD_UP -> "↑"
    KeyEvent.KEYCODE_DPAD_DOWN -> "↓"
    KeyEvent.KEYCODE_DPAD_LEFT -> "←"
    KeyEvent.KEYCODE_DPAD_RIGHT -> "→"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

/** Guarda vários perfis (um JSON por perfil) e lembra qual está ativo. */
class ProfileStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun names(): List<String> {
        val raw = sp.getString("names", "") ?: ""
        val list = raw.split("\n").filter { it.isNotBlank() }
        return if (list.isEmpty()) listOf("Padrão") else list
    }

    fun activeName(): String {
        val a = sp.getString("active", null)
        return if (a != null && a in names()) a else names().first()
    }

    fun setActive(name: String) { sp.edit().putString("active", name).apply() }

    fun load(name: String): Profile {
        val raw = sp.getString("p_$name", null) ?: return Profile(name = name)
        return try {
            Profile.fromJson(JSONObject(raw)).also { it.name = name }
        } catch (t: Throwable) {
            Profile(name = name)
        }
    }

    fun save(p: Profile) {
        val list = names().toMutableList()
        if (p.name !in list) list.add(p.name)
        sp.edit()
            .putString("names", list.joinToString("\n"))
            .putString("p_${p.name}", p.toJson().toString())
            .apply()
    }

    fun delete(name: String) {
        val list = names().toMutableList()
        list.remove(name)
        if (list.isEmpty()) list.add("Padrão")
        sp.edit()
            .putString("names", list.joinToString("\n"))
            .remove("p_$name")
            .apply()
        if (activeName() == name) setActive(list.first())
    }
}
