package com.example.ds4mepper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class PadState {
    var lx = 0f; var ly = 0f
    var rx = 0f; var ry = 0f
    var lt = 0f; var rt = 0f
    var hatX = 0f; var hatY = 0f
    val pressed = mutableSetOf<Int>()
}

/**
 * Desenha o controle no estilo neon. Cinza = valor bruto, colorido = depois do perfil.
 * Tocar em um elemento chama onTap com o nome dele (LS, RS, L2, R2, L1, R1, UP, DOWN, LEFT,
 * RIGHT, Y, A, X, B, SELECT, START, MODE).
 */
class GamepadView(ctx: Context) : View(ctx) {
    val state = PadState()
    var profile = Profile()
    /** true = o valor já veio processado pelo motor; não aplicar o perfil de novo. */
    var passthrough = false
    var onTap: ((String) -> Unit)? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val hits = ArrayList<Pair<RectF, String>>()

    private val cBlue = Color.rgb(46, 160, 255)
    private val cCyan = Color.rgb(0, 224, 212)
    private val cPink = Color.rgb(255, 72, 200)
    private val cRed = Color.rgb(255, 70, 92)
    private val cPurple = Color.rgb(150, 84, 255)
    private val cPanel = Color.rgb(20, 22, 52)
    private val cLabel = Color.rgb(206, 196, 255)

    // Mostra o botão de SAÍDA: se Cross foi remapeado para Circle, apertar Cross acende Circle.
    private fun down(vararg codes: Int) = codes.any { out ->
        state.pressed.any { p -> (if (passthrough) p else profile.map(p)) == out }
    }

    private fun tv(v: Float, cfg: TriggerCfg) = if (passthrough) v else cfg.process(v)

    private fun withAlpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    private fun glowCircle(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, w: Float) {
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(color, 26 * (4 - i))
            stroke.strokeWidth = w + i * 5f
            c.drawCircle(cx, cy, r, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = w
        c.drawCircle(cx, cy, r, stroke)
    }

    private fun glowRect(c: Canvas, r: RectF, rad: Float, color: Int, w: Float) {
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(color, 26 * (4 - i))
            stroke.strokeWidth = w + i * 5f
            c.drawRoundRect(r, rad, rad, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = w
        c.drawRoundRect(r, rad, rad, stroke)
    }

    private fun tap(r: RectF, tag: String) {
        hits.add(RectF(r) to tag)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            for ((r, tag) in hits) {
                if (r.contains(e.x, e.y)) {
                    onTap?.invoke(tag)
                    break
                }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        hits.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        text.textSize = h * 0.038f
        val u = h

        // ---------- corpo do controle (ao fundo) ----------
        val bw = min(w * 0.46f, h * 1.05f)
        val bh = bw * 0.60f
        val top = h * 0.56f - bh / 2f
        body(c, cx, top, bw, bh)

        // ---------- gatilhos e ombros ----------
        trigger(c, w * 0.03f, h * 0.02f, w * 0.29f, h * 0.085f, tv(state.lt, profile.lt), "L2", "L2")
        trigger(c, w * 0.68f, h * 0.02f, w * 0.29f, h * 0.085f, tv(state.rt, profile.rt), "R2", "R2")
        shoulder(c, w * 0.03f, h * 0.125f, w * 0.29f, h * 0.075f, down(KeyEvent.KEYCODE_BUTTON_L1), "L1", "L1")
        shoulder(c, w * 0.68f, h * 0.125f, w * 0.29f, h * 0.075f, down(KeyEvent.KEYCODE_BUTTON_R1), "R1", "R1")

        // ---------- D-pad ----------
        val d = u * 0.115f
        val br = u * 0.05f
        val dx = w * 0.13f
        val dy = h * 0.47f
        round(c, dx, dy - d, br, down(KeyEvent.KEYCODE_DPAD_UP), "↑", cBlue, "UP")
        round(c, dx, dy + d, br, down(KeyEvent.KEYCODE_DPAD_DOWN), "↓", cBlue, "DOWN")
        round(c, dx - d, dy, br, down(KeyEvent.KEYCODE_DPAD_LEFT), "←", cBlue, "LEFT")
        round(c, dx + d, dy, br, down(KeyEvent.KEYCODE_DPAD_RIGHT), "→", cBlue, "RIGHT")

        // ---------- botões de ação (Android A/B/X/Y = ✕/○/□/△ do DS4) ----------
        val fx = w * 0.87f
        round(c, fx, dy - d, br, down(KeyEvent.KEYCODE_BUTTON_Y), "△", cCyan, "Y")
        round(c, fx, dy + d, br, down(KeyEvent.KEYCODE_BUTTON_A), "✕", cBlue, "A")
        round(c, fx - d, dy, br, down(KeyEvent.KEYCODE_BUTTON_X), "□", cPink, "X")
        round(c, fx + d, dy, br, down(KeyEvent.KEYCODE_BUTTON_B), "○", cRed, "B")

        // ---------- centro: touchpad, Share, Options, PS ----------
        val tpW = bw * 0.30f
        val tpH = bh * 0.22f
        val tpTop = top + bh * 0.07f
        val tp = RectF(cx - tpW / 2f, tpTop, cx + tpW / 2f, tpTop + tpH)
        fill.color = Color.rgb(8, 10, 26)
        c.drawRoundRect(tp, 10f, 10f, fill)
        glowRect(c, tp, 10f, withAlpha(cBlue, 200), 2f)
        // barra de luz: mostra a cor do LED escolhida
        val led = if (profile.led) Color.rgb(profile.ledR, profile.ledG, profile.ledB) else cBlue
        stroke.color = withAlpha(led, 70); stroke.strokeWidth = 12f
        c.drawLine(tp.left + 8f, tp.top - 8f, tp.right - 8f, tp.top - 8f, stroke)
        stroke.color = led; stroke.strokeWidth = 5f
        c.drawLine(tp.left + 8f, tp.top - 8f, tp.right - 8f, tp.top - 8f, stroke)

        val pw = bw * 0.11f
        val ph = bh * 0.085f
        val py = top + bh * 0.12f
        pill(c, cx - bw * 0.27f - pw / 2f, py, pw, ph, down(KeyEvent.KEYCODE_BUTTON_SELECT), "Share", "SELECT")
        pill(c, cx + bw * 0.27f - pw / 2f, py, pw, ph, down(KeyEvent.KEYCODE_BUTTON_START), "Options", "START")
        round(c, cx, top + bh * 0.43f, u * 0.036f, down(KeyEvent.KEYCODE_BUTTON_MODE), "PS", cPurple, "MODE")

        // ---------- analógicos (no controle) ----------
        val sr = min(bw * 0.105f, h * 0.11f)
        val sy = top + bh * 0.62f
        stick(c, cx - bw * 0.19f, sy, sr, state.lx, state.ly, profile.left, down(KeyEvent.KEYCODE_BUTTON_THUMBL), "L3", "LS")
        stick(c, cx + bw * 0.19f, sy, sr, state.rx, state.ry, profile.right, down(KeyEvent.KEYCODE_BUTTON_THUMBR), "R3", "RS")
    }

    private fun body(c: Canvas, cx: Float, top: Float, bw: Float, bh: Float) {
        val main = RectF(cx - bw * 0.46f, top, cx + bw * 0.46f, top + bh * 0.80f)
        fill.color = Color.rgb(12, 13, 32)
        c.drawRoundRect(main, bh * 0.30f, bh * 0.30f, fill)
        // empunhaduras
        val gl = RectF(cx - bw * 0.52f, top + bh * 0.38f, cx - bw * 0.20f, top + bh * 1.00f)
        val gr = RectF(cx + bw * 0.20f, top + bh * 0.38f, cx + bw * 0.52f, top + bh * 1.00f)
        c.save(); c.rotate(14f, gl.centerX(), gl.centerY()); c.drawOval(gl, fill); c.restore()
        c.save(); c.rotate(-14f, gr.centerX(), gr.centerY()); c.drawOval(gr, fill); c.restore()
        glowRect(c, main, bh * 0.30f, withAlpha(cPurple, 190), 3f)
        c.save(); c.rotate(14f, gl.centerX(), gl.centerY())
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(cBlue, 18 * (4 - i)); stroke.strokeWidth = 3f + i * 4f
            c.drawOval(gl, stroke)
        }
        stroke.color = withAlpha(cBlue, 170); stroke.strokeWidth = 3f
        c.drawOval(gl, stroke); c.restore()
        c.save(); c.rotate(-14f, gr.centerX(), gr.centerY())
        for (i in 3 downTo 1) {
            stroke.color = withAlpha(cBlue, 18 * (4 - i)); stroke.strokeWidth = 3f + i * 4f
            c.drawOval(gr, stroke)
        }
        stroke.color = withAlpha(cBlue, 170); stroke.strokeWidth = 3f
        c.drawOval(gr, stroke); c.restore()
        // cobre o meio das empunhaduras para o corpo parecer uma peça só
        fill.color = Color.rgb(12, 13, 32)
        c.drawRoundRect(RectF(main.left + 4f, main.top + 4f, main.right - 4f, main.bottom - 4f), bh * 0.28f, bh * 0.28f, fill)
        stroke.color = withAlpha(cPurple, 120); stroke.strokeWidth = 2f
        c.drawRoundRect(main, bh * 0.30f, bh * 0.30f, stroke)
    }

    private fun round(c: Canvas, x: Float, y: Float, r: Float, pressed: Boolean, label: String, color: Int, tag: String) {
        fill.color = if (pressed) withAlpha(color, 170) else cPanel
        c.drawCircle(x, y, r, fill)
        glowCircle(c, x, y, r, color, 3f)
        val old = text.color
        text.color = if (pressed) Color.WHITE else color
        text.textSize = r * 1.0f
        c.drawText(label, x, y + text.textSize * 0.35f, text)
        text.color = old
        text.textSize = height * 0.038f
        tap(RectF(x - r * 1.2f, y - r * 1.2f, x + r * 1.2f, y + r * 1.2f), tag)
    }

    private fun pill(c: Canvas, l: Float, t: Float, w: Float, h: Float, pressed: Boolean, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = if (pressed) withAlpha(cBlue, 170) else cPanel
        c.drawRoundRect(rect, h / 2, h / 2, fill)
        glowRect(c, rect, h / 2, withAlpha(cBlue, 210), 2f)
        text.textSize = h * 0.55f
        c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        text.textSize = height * 0.038f
        tap(rect, tag)
    }

    private fun shoulder(c: Canvas, l: Float, t: Float, w: Float, h: Float, pressed: Boolean, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = if (pressed) withAlpha(cCyan, 150) else cPanel
        c.drawRoundRect(rect, 14f, 14f, fill)
        glowRect(c, rect, 14f, cCyan, 2.5f)
        badge(c, rect, label)
        c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        tap(rect, tag)
    }

    private fun trigger(c: Canvas, l: Float, t: Float, w: Float, h: Float, v: Float, label: String, tag: String) {
        val rect = RectF(l, t, l + w, t + h)
        fill.color = cPanel
        c.drawRoundRect(rect, 14f, 14f, fill)
        if (v > 0.001f) {
            fill.color = withAlpha(cCyan, 120)
            c.drawRoundRect(RectF(l, t, l + w * v.coerceIn(0f, 1f), t + h), 14f, 14f, fill)
        }
        glowRect(c, rect, 14f, cCyan, 2.5f)
        badge(c, rect, label)
        c.drawText("$label  ${"%.2f".format(v)}", rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        tap(rect, tag)
    }

    /** Quadradinho com o nome do botão, no canto esquerdo da barra. */
    private fun badge(c: Canvas, bar: RectF, label: String) {
        val s = bar.height() * 0.62f
        val b = RectF(bar.left + bar.height() * 0.18f, bar.centerY() - s / 2f, bar.left + bar.height() * 0.18f + s, bar.centerY() + s / 2f)
        stroke.color = cCyan; stroke.strokeWidth = 2f
        c.drawRoundRect(b, 6f, 6f, stroke)
        val old = text.textSize
        text.textSize = s * 0.50f
        text.color = cCyan
        c.drawText(label, b.centerX(), b.centerY() + text.textSize * 0.35f, text)
        text.color = Color.WHITE
        text.textSize = old
    }

    private fun stick(c: Canvas, cx: Float, cy: Float, r: Float, rawX: Float, rawY: Float, cfg: StickCfg, pressed: Boolean, label: String, tag: String) {
        fill.color = if (pressed) withAlpha(cPurple, 190) else Color.rgb(10, 12, 30)
        c.drawCircle(cx, cy, r, fill)
        glowCircle(c, cx, cy, r, cBlue, 4f)
        // zona morta configurada
        val dz = Paint(stroke).apply {
            color = cPurple
            strokeWidth = 2f
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }
        c.drawCircle(cx, cy, r * cfg.deadzone, dz)
        // valor bruto (cinza)
        fill.color = Color.GRAY
        c.drawCircle(cx + rawX * r, cy + rawY * r, r * 0.12f, fill)
        // valor processado
        val (px, py) = if (passthrough) (rawX to rawY) else cfg.process(rawX, rawY, profile.invertY)
        fill.color = cCyan
        c.drawCircle(cx + px * r, cy + py * r, r * 0.17f, fill)
        val old = text.textSize
        text.textSize = old * 0.80f
        text.color = cLabel
        c.drawText(label, cx, cy - r - old * 0.35f, text)
        c.drawText("%.2f  %.2f".format(px, py), cx, cy + r + old * 1.05f, text)
        text.color = Color.WHITE
        text.textSize = old
        tap(RectF(cx - r, cy - r, cx + r, cy + r), tag)
    }
}
