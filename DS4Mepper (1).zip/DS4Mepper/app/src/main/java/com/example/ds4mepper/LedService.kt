package com.example.ds4mepper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import kotlin.concurrent.thread

/**
 * Serviço em primeiro plano que mantém o app vivo para a cor do LED não apagar.
 * Também reaplica a cor quando o controle reconecta. Só roda enquanto o perfil ativo
 * tiver "Usar cor personalizada" ligado.
 */
class LedService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var inputManager: InputManager

    private val listener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            // O DS4 volta à cor padrão ao reconectar: espera um pouco e aplica de novo.
            handler.postDelayed({ applyFromProfile() }, 800)
        }
        override fun onInputDeviceRemoved(deviceId: Int) {}
        override fun onInputDeviceChanged(deviceId: Int) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        inputManager.registerInputDeviceListener(listener, handler)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        applyFromProfile()
        return START_STICKY
    }

    private fun applyFromProfile() {
        val store = ProfileStore(this)
        val p = store.load(store.activeName())
        if (!p.led) {
            stopSelf()
            return
        }
        thread { LedCtl.set(p.ledR, p.ledG, p.ledB) }
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "LED do controle", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("DS4 Mepper")
            .setContentText("Mantendo a cor do LED do controle")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        inputManager.unregisterInputDeviceListener(listener)
        handler.removeCallbacksAndMessages(null)
        LedCtl.release()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "led"
        private const val NOTIF_ID = 42

        /** Liga o serviço (precisa ser chamado com o app visível, regra do Android). */
        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, LedService::class.java))
            } catch (t: Throwable) {
                // Se o Android não deixar iniciar agora (app em segundo plano), o app ainda aplica a cor sozinho.
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LedService::class.java))
        }
    }
}
