package com.example.ds4mepper

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.Locale

/** Liga, desliga e configura o motor (PadEngine) que roda em segundo plano pelo Shizuku. */
object PadEngineCtl {
    /** Nome do controle virtual que o motor cria. */
    const val DEVICE_NAME = "DS4Mepper Virtual Controller"

    private const val CFG = "/data/local/tmp/ds4mepper.cfg"
    private const val PID = "/data/local/tmp/ds4mepper.pid"
    private const val STATUS = "/data/local/tmp/ds4mepper.status"
    private const val LOG = "/data/local/tmp/ds4mepper.log"

    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (t: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    // O método newProcess é privado nas versões novas da API, então chamo por reflexão.
    fun sh(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (t: Throwable) {
            "ERRO: ${t.cause ?: t}"
        }
    }

    private fun f(v: Float) = String.format(Locale.US, "%.4f", v)

    private fun cfgText(p: Profile, enabled: Boolean): String {
        val remap = p.remap.entries.joinToString(",") { "${it.key}:${it.value}" }
        val turbo = p.turbo.joinToString(",")
        return "enabled=${if (enabled) 1 else 0}\n" +
            "lzone=${f(p.left.deadzone)}\n" +
            "lcurve=${f(p.left.curve)}\n" +
            "rzone=${f(p.right.deadzone)}\n" +
            "rcurve=${f(p.right.curve)}\n" +
            "lsens=${f(p.left.sens)}\n" +
            "rsens=${f(p.right.sens)}\n" +
            "ltstart=${f(p.lt.start)}\n" +
            "ltmax=${f(p.lt.max)}\n" +
            "ltcurve=${f(p.lt.curve)}\n" +
            "rtstart=${f(p.rt.start)}\n" +
            "rtmax=${f(p.rt.max)}\n" +
            "rtcurve=${f(p.rt.curve)}\n" +
            "invertY=${if (p.invertY) 1 else 0}\n" +
            "turboon=${p.turboOn}\n" +
            "turbooff=${p.turboOff}\n" +
            "turbodelay=${p.turboDelay}\n" +
            "turbo=$turbo\n" +
            "remap=$remap\n"
    }

    // O texto só tem letras, números e : , . = e quebras de linha, então é seguro no printf.
    private fun writeCfg(text: String) {
        val esc = text.replace("\n", "\\n")
        sh("printf '$esc' > $CFG")
    }

    /** Envia os ajustes atuais para o motor (ele aplica na hora). */
    fun pushConfig(p: Profile) = writeCfg(cfgText(p, true))

    /**
     * Encerra motores de OUTROS apps (PadPulse, StickLab, PadTool...). Se um deles já estiver com o
     * DS4 bloqueado, o DS4 Mepper não consegue pegar o controle e o motor para na hora.
     * Não mexe no próprio motor (cmdline com "ds4mepper") nem no shell que roda este comando.
     */
    private fun killOtherEngines(): String {
        val script = "for D in /proc/[0-9]*; do " +
            "N=\${D#/proc/}; [ \"\$N\" = \"\$\$\" ] && continue; " +
            "C=\$(tr '\\0' ' ' < \$D/cmdline 2>/dev/null); " +
            "case \"\$C\" in *app_process*.PadEngine*) " +
            "case \"\$C\" in *ds4mepper*) ;; *) kill \$N 2>/dev/null; echo \"encerrado \$N\";; esac;; " +
            "esac; done; sleep 0.5"
        return sh(script)
    }

    fun start(apk: String, p: Profile): String {
        killOtherEngines()
        writeCfg(cfgText(p, true))
        val script = "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then echo JA_RODANDO; else " +
            "if command -v setsid >/dev/null 2>&1; then L=setsid; else L=; fi; " +
            "CLASSPATH='$apk' nohup \$L app_process /system/bin com.example.ds4mepper.PadEngine " +
            "> $LOG 2>&1 < /dev/null & " +
            "echo INICIADO; fi"
        return sh(script)
    }

    fun stop(): String {
        val script = "printf 'enabled=0\\n' > $CFG; sleep 1; " +
            "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then kill \$P; fi; " +
            "echo PARADO"
        return sh(script)
    }

    /** Primeira linha: RODANDO ou PARADO. Depois, o que o motor escreveu sobre si mesmo. */
    fun status(): String {
        if (!alive()) return "SEM_SHIZUKU"
        if (!granted()) return "SEM_PERMISSAO"
        val script = "P=\$(cat $PID 2>/dev/null); " +
            "if [ -n \"\$P\" ] && grep -qa PadEngine /proc/\$P/cmdline 2>/dev/null; then " +
            "echo RODANDO; cat $STATUS 2>/dev/null; else echo PARADO; grep -a '^ERRO' $STATUS 2>/dev/null | head -n 1; fi"
        return sh(script)
    }

    fun log(): String = sh("cat $LOG 2>/dev/null | tail -n 15")
}
